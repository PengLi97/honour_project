README

  Fight the landlord is a famous game in Chinese folk, the people in china usually
  familiar call it dou dizhu.  During culture relation in China, people were suffering i
  n class struggle, peasants start used their own way to against the landlords and richer,
  Fight the landlord was been created on that time.

To run:
  phython StartUI

GUID:
  guid_button: rule of the game.
  start_button: start the main page of the game.
  level_button: provide three level the computer player.
  AI_button: let computer play the game for you.
  load_button: loading the previous unfinished game.
  new_game_button: start a new game.

  * More detail in report

NOTICE:
  Carleton University 2020 Fall term
  course: COMP 4905 Honour project
  Student ID: 101047123
  Student: Peng Li
  Data: Dec 13th 2020

  Copyright© 2020. Peng Li
